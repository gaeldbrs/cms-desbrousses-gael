<?php exit('Access denied'); __halt_compiler(); ?>
******************************************************************
This file is used by the Wordfence Web Application Firewall. Read 
more at https://docs.wordfence.com/en/Web_Application_Firewall_FAQ
******************************************************************
a:7:{s:9:"wafStatus";s:13:"learning-mode";s:30:"learningModeGracePeriodEnabled";i:1;s:23:"learningModeGracePeriod";i:1648799485;s:7:"authKey";s:64:"NFS^-uQ*]8:zIYz-QCq5]1*;ugz,=5YgTc_(l.60oDat$.5(3]b:s*76~b8MhTZ ";s:7:"version";s:5:"1.0.4";s:13:"attackDataKey";i:837;s:11:"wafDisabled";b:1;}